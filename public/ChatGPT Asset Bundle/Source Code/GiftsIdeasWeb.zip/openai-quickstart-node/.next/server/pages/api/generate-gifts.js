"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/generate-gifts";
exports.ids = ["pages/api/generate-gifts"];
exports.modules = {

/***/ "openai":
/*!*************************!*\
  !*** external "openai" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("openai");

/***/ }),

/***/ "(api)/./pages/api/generate-gifts.js":
/*!*************************************!*\
  !*** ./pages/api/generate-gifts.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! openai */ \"openai\");\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_0__);\n\nconst configuration = new openai__WEBPACK_IMPORTED_MODULE_0__.Configuration({\n    apiKey: process.env.OPENAI_API_KEY\n});\nconst openai = new openai__WEBPACK_IMPORTED_MODULE_0__.OpenAIApi(configuration);\n/* harmony default export */ async function __WEBPACK_DEFAULT_EXPORT__(req, res) {\n    const { priceMin , priceMax , gender , age , hobbies  } = req.body;\n    const completion = await openai.createCompletion({\n        model: \"text-davinci-003\",\n        prompt: generatePrompt(priceMin, priceMax, gender, age, hobbies),\n        temperature: 0.6,\n        max_tokens: 2048\n    });\n    res.status(200).json({\n        result: completion.data.choices[0].text\n    });\n};\nfunction generatePrompt(priceMin, priceMax, gender, age, hobbies) {\n    return `suggest 3 Christmas gift ideas between ${priceMin}$ and ${priceMax}$ for a ${age} years old ${gender} that is into ${hobbies}.`;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2VuZXJhdGUtZ2lmdHMuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWtEO0FBRWxELE1BQU1FLGFBQWEsR0FBRyxJQUFJRixpREFBYSxDQUFDO0lBQ3RDRyxNQUFNLEVBQUVDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxjQUFjO0NBQ25DLENBQUM7QUFDRixNQUFNQyxNQUFNLEdBQUcsSUFBSU4sNkNBQVMsQ0FBQ0MsYUFBYSxDQUFDO0FBRTNDLDZCQUFlLDBDQUFnQk0sR0FBRyxFQUFFQyxHQUFHLEVBQUU7SUFDdkMsTUFBTSxFQUFFQyxRQUFRLEdBQUVDLFFBQVEsR0FBRUMsTUFBTSxHQUFFQyxHQUFHLEdBQUVDLE9BQU8sR0FBRSxHQUFHTixHQUFHLENBQUNPLElBQUk7SUFDN0QsTUFBTUMsVUFBVSxHQUFHLE1BQU1ULE1BQU0sQ0FBQ1UsZ0JBQWdCLENBQUM7UUFDL0NDLEtBQUssRUFBRSxrQkFBa0I7UUFDekJDLE1BQU0sRUFBRUMsY0FBYyxDQUFDVixRQUFRLEVBQUVDLFFBQVEsRUFBRUMsTUFBTSxFQUFFQyxHQUFHLEVBQUVDLE9BQU8sQ0FBQztRQUNoRU8sV0FBVyxFQUFFLEdBQUc7UUFDaEJDLFVBQVUsRUFBRSxJQUFJO0tBQ2pCLENBQUM7SUFDRmIsR0FBRyxDQUFDYyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQztRQUFFQyxNQUFNLEVBQUVULFVBQVUsQ0FBQ1UsSUFBSSxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUk7S0FBRSxDQUFDLENBQUM7Q0FDbkU7QUFDRCxTQUFTUixjQUFjLENBQUNWLFFBQVEsRUFBRUMsUUFBUSxFQUFFQyxNQUFNLEVBQUVDLEdBQUcsRUFBRUMsT0FBTyxFQUFFO0lBQ2hFLE9BQU8sQ0FBQyx1Q0FBdUMsRUFBRUosUUFBUSxDQUFDLE1BQU0sRUFBRUMsUUFBUSxDQUFDLFFBQVEsRUFBRUUsR0FBRyxDQUFDLFdBQVcsRUFBRUQsTUFBTSxDQUFDLGNBQWMsRUFBRUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ3pJIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vb3BlbmFpLXF1aWNrc3RhcnQtbm9kZS8uL3BhZ2VzL2FwaS9nZW5lcmF0ZS1naWZ0cy5qcz9mYjFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbmZpZ3VyYXRpb24sIE9wZW5BSUFwaSB9IGZyb20gXCJvcGVuYWlcIjtcblxuY29uc3QgY29uZmlndXJhdGlvbiA9IG5ldyBDb25maWd1cmF0aW9uKHtcbiAgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSxcbn0pO1xuY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSUFwaShjb25maWd1cmF0aW9uKTtcblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gKHJlcSwgcmVzKSB7XG4gIGNvbnN0IHsgcHJpY2VNaW4sIHByaWNlTWF4LCBnZW5kZXIsIGFnZSwgaG9iYmllcyB9ID0gcmVxLmJvZHk7XG4gIGNvbnN0IGNvbXBsZXRpb24gPSBhd2FpdCBvcGVuYWkuY3JlYXRlQ29tcGxldGlvbih7XG4gICAgbW9kZWw6IFwidGV4dC1kYXZpbmNpLTAwM1wiLFxuICAgIHByb21wdDogZ2VuZXJhdGVQcm9tcHQocHJpY2VNaW4sIHByaWNlTWF4LCBnZW5kZXIsIGFnZSwgaG9iYmllcyksXG4gICAgdGVtcGVyYXR1cmU6IDAuNixcbiAgICBtYXhfdG9rZW5zOiAyMDQ4LFxuICB9KTtcbiAgcmVzLnN0YXR1cygyMDApLmpzb24oeyByZXN1bHQ6IGNvbXBsZXRpb24uZGF0YS5jaG9pY2VzWzBdLnRleHQgfSk7XG59XG5mdW5jdGlvbiBnZW5lcmF0ZVByb21wdChwcmljZU1pbiwgcHJpY2VNYXgsIGdlbmRlciwgYWdlLCBob2JiaWVzKSB7XG4gIHJldHVybiBgc3VnZ2VzdCAzIENocmlzdG1hcyBnaWZ0IGlkZWFzIGJldHdlZW4gJHtwcmljZU1pbn0kIGFuZCAke3ByaWNlTWF4fSQgZm9yIGEgJHthZ2V9IHllYXJzIG9sZCAke2dlbmRlcn0gdGhhdCBpcyBpbnRvICR7aG9iYmllc30uYDtcbn1cbiJdLCJuYW1lcyI6WyJDb25maWd1cmF0aW9uIiwiT3BlbkFJQXBpIiwiY29uZmlndXJhdGlvbiIsImFwaUtleSIsInByb2Nlc3MiLCJlbnYiLCJPUEVOQUlfQVBJX0tFWSIsIm9wZW5haSIsInJlcSIsInJlcyIsInByaWNlTWluIiwicHJpY2VNYXgiLCJnZW5kZXIiLCJhZ2UiLCJob2JiaWVzIiwiYm9keSIsImNvbXBsZXRpb24iLCJjcmVhdGVDb21wbGV0aW9uIiwibW9kZWwiLCJwcm9tcHQiLCJnZW5lcmF0ZVByb21wdCIsInRlbXBlcmF0dXJlIiwibWF4X3Rva2VucyIsInN0YXR1cyIsImpzb24iLCJyZXN1bHQiLCJkYXRhIiwiY2hvaWNlcyIsInRleHQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/generate-gifts.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/generate-gifts.js"));
module.exports = __webpack_exports__;

})();